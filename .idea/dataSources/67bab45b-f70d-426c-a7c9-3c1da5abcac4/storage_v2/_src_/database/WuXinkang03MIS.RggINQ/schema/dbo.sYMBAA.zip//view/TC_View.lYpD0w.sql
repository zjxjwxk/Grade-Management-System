CREATE VIEW TC_View AS
SELECT wxk_Cteacher, wuxk_Courses.wxk_Cno, wxk_Cterm, wxk_Classno, wxk_Cname, wxk_Chours, wxk_Ccredit, wxk_Ctype
FROM wuxk_Courses, wuxk_CC
WHERE wuxk_Courses.wxk_Cno = wuxk_CC.wxk_Cno;
go

