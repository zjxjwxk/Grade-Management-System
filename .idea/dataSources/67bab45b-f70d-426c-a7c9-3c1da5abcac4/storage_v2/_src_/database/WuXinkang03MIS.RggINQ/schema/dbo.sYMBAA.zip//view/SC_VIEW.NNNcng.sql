CREATE VIEW SC_VIEW AS
SELECT wxk_Sno, wxk_Cterm, wxk_Cname, wxk_Tname, wxk_Chours, wxk_Ccredit, wxk_Ctype, wxk_Cstatus
FROM wuxk_SC, wuxk_Courses, wuxk_Teachers
WHERE wuxk_Courses.wxk_Cno = wuxk_SC.wxk_Cno
	AND wuxk_Courses.wxk_Cteacher = wuxk_Teachers.wxk_Tno;
go

