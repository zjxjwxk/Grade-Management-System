CREATE VIEW ClassCourse_View AS
SELECT wuxk_CC.wxk_Cno, wuxk_CC.wxk_Classno, wxk_Cterm, wxk_Cname, wxk_Tname, wxk_Chours, wxk_Ccredit, wxk_Ctype
FROM wuxk_CC, wuxk_Courses, wuxk_Teachers, wuxk_Class
WHERE wuxk_Courses.wxk_Cno = wuxk_CC.wxk_Cno
	AND wuxk_Class.wxk_Classno = wuxk_CC.wxk_Classno
	AND wuxk_Courses.wxk_Cteacher = wuxk_Teachers.wxk_Tno;
go

