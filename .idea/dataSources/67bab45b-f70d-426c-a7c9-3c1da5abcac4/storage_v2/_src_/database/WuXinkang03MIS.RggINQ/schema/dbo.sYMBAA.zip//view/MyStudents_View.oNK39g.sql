CREATE VIEW MyStudents_View AS
SELECT wuxk_SC.wxk_Sno, wuxk_Teachers.wxk_Tno, wxk_Sname, wxk_Classno, wxk_Cterm, wxk_Cname, wuxk_SC.wxk_Cno
FROM wuxk_Students, wuxk_Courses, wuxk_Teachers, wuxk_SC
WHERE wuxk_SC.wxk_Sno = wuxk_Students.wxk_Sno
	AND wuxk_SC.wxk_Cno = wuxk_Courses.wxk_Cno
	AND wuxk_Courses.wxk_Cteacher = wuxk_Teachers.wxk_Tno;
go

