CREATE VIEW Class_View AS
SELECT wxk_Classno, wxk_Dname
FROM wuxk_Class, wuxk_Department
	WHERE wuxk_Class.wxk_Dno = wuxk_Department.wxk_Dno;
go

