CREATE VIEW StuScore_VIEW AS
SELECT wuxk_Score.wxk_Sno, wxk_Sname, wxk_Cterm, wxk_Classno, wxk_Cname, wxk_Tname, wxk_Chours, wxk_Ccredit, wxk_Ctype, wxk_Score
FROM wuxk_Score, wuxk_Courses, wuxk_Teachers, wuxk_Students
WHERE wuxk_Courses.wxk_Cno = wuxk_Score.wxk_Cno
	AND wuxk_Score.wxk_Tno = wuxk_Teachers.wxk_Tno
	AND wuxk_Score.wxk_Sno = wuxk_Students.wxk_Sno;
go

