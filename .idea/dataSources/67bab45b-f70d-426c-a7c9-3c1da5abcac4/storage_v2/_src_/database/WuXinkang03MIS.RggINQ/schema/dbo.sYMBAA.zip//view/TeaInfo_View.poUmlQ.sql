CREATE VIEW TeaInfo_View AS
SELECT wxk_Tno, wxk_Tname, wxk_Tsex, wxk_Tage, wxk_Ttitle, wxk_Tphone
FROM wuxk_Teachers;
go

