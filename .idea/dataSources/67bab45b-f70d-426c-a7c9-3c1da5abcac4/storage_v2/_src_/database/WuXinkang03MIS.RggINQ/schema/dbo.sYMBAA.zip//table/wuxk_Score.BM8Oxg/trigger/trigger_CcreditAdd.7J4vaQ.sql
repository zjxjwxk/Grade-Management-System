CREATE TRIGGER trigger_CcreditAdd
ON wuxk_Score
FOR INSERT
AS
BEGIN
if (SELECT wxk_Score FROM inserted) >= 60
	UPDATE wuxk_SC SET wxk_Cstatus = '已修'
	FROM wuxk_SC, inserted
	WHERE wuxk_SC.wxk_Sno = inserted.wxk_Sno;
if (SELECT wxk_Score FROM inserted) >= 60
	UPDATE wuxk_Students SET wxk_Scredit = 
		(SELECT SUM(wxk_Ccredit)
			FROM wuxk_SC, wuxk_Courses, inserted
			WHERE wuxk_SC.wxk_Sno = inserted.wxk_Sno
			AND wuxk_SC.wxk_Cno = wuxk_Courses.wxk_Cno
			AND wuxk_SC.wxk_Cstatus = '已修')
		FROM inserted
		WHERE wuxk_Students.wxk_Sno = inserted.wxk_Sno;
else
	UPDATE wuxk_SC SET wxk_Cstatus = '不及格' 
	FROM wuxk_SC, inserted
	WHERE wuxk_SC.wxk_Sno = inserted.wxk_Sno
END
go

