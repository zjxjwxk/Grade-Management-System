CREATE VIEW Score_View AS
SELECT wuxk_Students.wxk_Sno, wuxk_Score.wxk_Tno, wxk_Sname, wxk_Classno, wxk_term, wxk_Cname, wuxk_score.wxk_Cno, wxk_Tname, wxk_score
FROM wuxk_Score, wuxk_Students, wuxk_Courses, wuxk_Teachers
WHERE wuxk_Score.wxk_Sno = wuxk_Students.wxk_Sno
	AND wuxk_Score.wxk_Cno = wuxk_Courses.wxk_Cno
	AND wuxk_Score.wxk_Tno = wuxk_Teachers.wxk_Tno;
go

