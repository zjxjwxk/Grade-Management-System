CREATE VIEW StuInfo_View AS
SELECT wxk_Sno, wxk_Sname, wuxk_Students.wxk_Dno, wxk_Dname, wxk_Classno, wxk_Ssex, wxk_Sage, wxk_Saddress, wxk_Scredit
FROM wuxk_Students, wuxk_Department
WHERE wuxk_Students.wxk_Dno = wuxk_Department.wxk_Dno;
go

